﻿using System;
using System.Collections.Generic;
using System.Text;
using BaseFramework.Model;
using BaseFramework.Rest;

namespace BaseFramework.Helpers
{
    //We are probably going to need some helper methods to process data
    public class FrameworkHelper
    {
        public static User GetUserAuthToken(String username, String password)
        {
            //Put some code in here to get an authorization token for a user.
            //This will make it easier to get an authorization token each time its needed.

            return default(User);  //Replace this with an actual return that is useful.
        }
    }
}

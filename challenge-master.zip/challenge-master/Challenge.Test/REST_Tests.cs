﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Challenge.Test
{
    [TestClass]
    public class REST_Tests
    {
        [TestMethod]
        public void Objective_3_Task1_Positive()
        {
        }
    }

}

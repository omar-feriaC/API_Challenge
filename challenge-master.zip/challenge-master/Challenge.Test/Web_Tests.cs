﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Challenge.Test
{
    [TestClass]
    public class Web_Tests
    {
        [TestMethod]
        public void MainPage_Correct_Selections_Positive()
        {
        }
    }
}
